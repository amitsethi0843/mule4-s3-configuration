

def httpRequest(String url, String method, Map params = null) throws Exception {
	
	String paramsStr =  params ? new groovy.json.JsonBuilder(params).toPrettyString() :  null

	
}

return this
