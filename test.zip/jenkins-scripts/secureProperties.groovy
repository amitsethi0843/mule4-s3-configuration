
void secureProperties (String path){
	try{
		def fileName = path + "/mule-artifact.json"
		def artifcatJson = readJSON file: fileName
		def secureProperties = artifcatJson.secureProperties ? ((java.util.HashSet<String>) artifcatJson.secureProperties) : []
		secureProperties << "mule.key"
		secureProperties << "anypoint.platform.client_secret"
		secureProperties << "anypoint.platform.client_id"
		secureProperties << "mule.securekey"
		secureProperties << "sfdcCPQ.securityToken"
		secureProperties << "sfdcCPQ.pwd"
		secureProperties <<	"mule.ddApiKey"

		artifcatJson.secureProperties = secureProperties
		
		writeJSON file: fileName, json: artifcatJson
	}
	catch(Exception ex){
		print "---------- Error occured ---------- " + ex.getMessage()
		throw ex
	}

}

return this
