# Ciena MuleSoft/Salesforce/Mavenlink Project

Ciena Parent build project for SalesForce Mulesoft Applications

## Install Maven
### Download the latest stable version of Maven from the official website, as of now the latest stable version is 3.6.3:
  - Go to https://maven.apache.org/download.cgi
  - Select the suggested mirror.
  - Navigate to maven/maven-3/3.6.3/binaries/ and download the binaries (zip or .gz).

### Unzip/Install
Maven doesn't have an installer. Simply unzip the file and place the resulting apache-maven-[version] folder (apache-maven-3.6.3 for this tutorial) in an easy to remember location. Try to pick a location outside of your common downloads and temporary files to prevent the folder being deleted by accident. For example:
  - Mac: /Users/developer/apache-maven-3.6.3
  - Windows: C:\Users\Developer\apache-maven-3.6.3

### Set User Environmental Variables
```
SET M2_HOME=C:\Users\Developer\apache-maven-3.6.3
SET JAVA_HOME=C:\Program Files\Java\jdk1.8.0_191
SET PROJECT_HOME=C:\Users\Developer\git\ciena
```

### Update User 'Path' Environmental Variable with 2 values below:
```
%JAVA_HOME%\bin
%M2_HOME%\bin
```

### Update Maven settings.xml
```
Copy %PROJECT_HOME%\tools\maven\settings.xml to %USER_HOME%\.m2
Open settings.xml and update credentials for all the <server> items as necessary.
Save XML file.
```
## Initial Oracle Driver and other commercial library Installation (needs to be done only once):
```
cd C:\
cd %PROJECT_HOME%\tools\maven
maven.bat
```

## Build all projects
```
cd C:\
cd %PROJECT_HOME%
mvn clean install -DskipTests
```

## Build specific project.
```
cd $PROJECT_HOME/ciena-commons
%MAVEN_HOME%\mvn clean install -DskipTests
```

## Importing projects.
Please import projects into Anypoint Studio using "Import->Anypoint Studio/Anypoint Studio project from File System" menu.

++IMPORTANT++: Uncheck "Copy project into workspace" option unless your Git repository is checked out into workspace which is highly discouraged.

++IMPORTANT++: Build project is not a Mule 4 project it's a folder with parent build pom.xml and should NOT be imported.

## Import all other projects next.

## Running Projects in Studio:
- Additional JVM Arguments required:
```
-Dmule.env=local 
-Dmule.key=changeit 
```
- Optional:
```
-Xmx2048m
-XX:MaxMetaspaceSize=512m
-Danypoint.platform.gatekeeper=disabled
```

++IMPORTANT++: The Commons project is not a Mule 4 project it's a library so you cannot "run" it.

## Deploy specific project to CloudHub (SIT)
```
mvn install mule:deploy -P=sit -DskipTests -DMULE_KEY=changeit -DCLOUDHUB_USER=<CLOUDHUB-USER> -DCLOUDHUB_PASSWORD=<CLOUDHUB-PASSWORD> -DCLOUDHUB_CLIENT_ID=<CLOUDHUB-ENV-CLIENT-ID> -DCLOUDHUB_CLIENT_SECRET=<CLOUDHUB-ENV-CLIENT-SECRET>  -DCLOUDHUB_BUSINESS_GROUP="Salesforce Delivery" -DHTTPS_KEYSTORE_KEYPWD=<DEFAULT KEYSTORE PW>
```